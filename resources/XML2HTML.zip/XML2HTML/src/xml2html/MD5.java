/*
 * MD5.java
 *
 * Created on 18 April 2006, 15:29
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package xml2html;

/**
 *
 * @author Shlomo Geva
 */
//public class MD5 {
//    
//    /** Creates a new instance of MD5 */
//    public MD5() {
//    }
//    
//}

import java.security.*;

/**
 * <u>MD5-Klasse, zum erzeugen von MD5-Hashes aus Zeichenketten</u><br><br>
 * <b>Class:</b> MD5<br><br>
 * <b>Java-Version:</b> 1.5x<br><br>
 * <b>&copy; Copyright:</b> Karsten Bettray - 2006<br><br>
 * <b>License:</b> Free for non commercial use, for all educational institutions (Schools, Universities ...) and it members<br>
  * @author Karsten Bettray (Universit&auml;t Duisburg-Essen)<br><br>
 * @version 0.1<br>
 *
 */
public class MD5{
	/**
	 * <u>MD5-Hash erzeugen</u>
	 * @return
	 */
        
        // MD5-Hash of "Test": 0cbc6611f5540bd0809a388dc95a615b
	public static String GetMD5(String text)
	{
		MessageDigest md = null;
		byte[] encryptMsg = null;

		try {
			md = MessageDigest.getInstance( "MD5" );		// getting a 'MD5-Instance'
			encryptMsg = md.digest(text.getBytes());		// solving the MD5-Hash
		}catch (NoSuchAlgorithmException e) {
			System.out.println("No Such Algorithm Exception!");
		}
			
		String swap="";										// swap-string for the result
		String byteStr="";									// swap-string for current hex-value of byte
		StringBuffer strBuf = new StringBuffer();
		
		for(int i=0; i<=encryptMsg.length-1; i++) {
			
			byteStr = Integer.toHexString(encryptMsg[i]);	// swap-string for current hex-value of byte
			
			switch(byteStr.length()) {
			case 1:											// if hex-number length is 1, add a '0' before
				swap = "0"+Integer.toHexString(encryptMsg[i]);
				break;
				
			case 2:											// correct hex-letter
				swap = Integer.toHexString(encryptMsg[i]);
				break;
				
			case 8:											// get the correct substring
				swap = (Integer.toHexString(encryptMsg[i])).substring(6,8);
				break;
			}
			strBuf.append(swap);							// appending swap to get complete hash-key
		}
		String hash = strBuf.toString();							// String with the MD5-Hash
		
		return hash;										// returns the MD5-Hash
	}
}
	

