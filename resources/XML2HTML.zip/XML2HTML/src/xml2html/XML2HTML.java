package xml2html;

import java.io.*;
//import java.util.*;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamSource;
import javax.xml.transform.stream.StreamResult;

/**
 * This class converts a set of XML documents into HTML documents as 
 * specified by the transformations specified by an XSLT
 * 
 * @author Alan Woodley
 */
public class XML2HTML {
    
    // transformer
    Transformer trans;
    
    /** 
      * Creates a XML2HTML object
      * @param xsltFilename - The XSLT file that contains the transformations
      */
    public XML2HTML(String xsltFilename){
        try {
            File xsltFile = new File(xsltFilename);
            if(!xsltFile.exists()) {
                System.out.println("Error - XSLT Does not exist");
                System.exit(-1);
            }
            javax.xml.transform.Source xsltSource = new javax.xml.transform.stream.StreamSource(xsltFile);
            javax.xml.transform.TransformerFactory transFact = javax.xml.transform.TransformerFactory.newInstance();
            trans = transFact.newTransformer(xsltSource);
        } catch (Exception e){
            e.printStackTrace();
        }
    }


    /**
     * Public interface to the class. Converts a (set of) XML document/s to
     * (a set of) HTML document/s.
     * 
     * @param inname - The XML file or directory
     * @param outname - The directory to store the HTML files
     */    
    public void ConvertXMLToHTML(String inname, String outname){
//        System.out.println("Converting " + inname);
        inname = inname.replace('/', File.separatorChar);
        outname = outname.replace('/', File.separatorChar);   
        ConvertXMLToHTMLRecursive(inname, outname);
    }
    
    /**
      * This method will recursively convert a xml file (or directory of xml files) into a 
      * HTML file (or directory of HTML files)
      * 
      * @param inname - The XML file or directory
      * @param outname - The directory to store the HTML files
      */
    private void ConvertXMLToHTMLRecursive(String inname, String outname){       
        File in = new File(inname);
        if(!in.exists()) {
             System.out.println("Error - Input file " + inname + " does not exist");
             System.out.println("conversation not successful");
             System.exit(-1);
             
        }
        if (in.isFile()){
            // if we have an XML file then process it
            if (inname.toUpperCase().endsWith(Global.XML_SUFFIX)) {
                // replace the .xml with a .txt
               
                if(outname.toUpperCase().endsWith(Global.XML_SUFFIX)) outname = outname.substring(0,outname.length() - Global.XML_SUFFIX_LENGTH) + Global.HTML_SUFFIX;
                else if (outname.toUpperCase().endsWith(Global.HTML_SUFFIX)) ; // do nothing
                else outname += Global.HTML_SUFFIX;
                
                ConvertXMLFileToHTML(inname, outname);
                
            }
        } else if (in.isDirectory()){
            // if we have a directory then process all of its file and subdirectories
            if (!inname.endsWith(File.separator)) inname += File.separator;
            if (!outname.endsWith(File.separator)) outname += File.separator;
            System.out.println("Trying to convert directory " + inname);
            File out = new File(outname);
            if(!out.exists()) out.mkdirs();
            String[] children = in.list();
            for(int i=0;i<children.length;i++){
                ConvertXMLToHTMLRecursive(inname + children[i],outname + children[i]);
            }
        } else {
            // do nothing           
        }
    }
    
    /** 
      * This method will convert a given XML file into a HTML file 
      * @param xmlFilename - The XML file
      * @param htmlFilename - The HTML file      
      */
    private void ConvertXMLFileToHTML(String xmlFilename, String htmlFilename){
        try{
//            System.out.println("Converting File " + xmlFilename  + " to " + htmlFilename);
            File xmlFile = new File(xmlFilename);
            Source xmlSource = new StreamSource(xmlFile);
            File htmlFile = new File(htmlFilename.toLowerCase());
            StreamResult htmlDestination = new StreamResult(htmlFile);
            htmlDestination.setWriter(new OutputStreamWriter(new FileOutputStream(htmlFile),"UTF-8"));
            trans.transform(xmlSource,  htmlDestination);
        } catch (Exception e) {
            System.out.println("OOPS!! "+xmlFilename);
            e.printStackTrace();
        }
    }
    
     /**
     * Prints a status message on how to use this program
     */
    private static void PrintStatusMessage(){
            System.out.println("XML2HTML Version 1.0 By Alan Woodley");                      
            System.out.println("This program accepts an XML file (or directory of XML files) ");
            System.out.println("and transforms it (them) to HTML files. Transformations are.");
            System.out.println("specified by the accompanied XSLT file.");
            System.out.println("");
            System.out.println("Usage: java -jar xml2txt.jar input output xslt"); 
            System.out.println("Where: ");
            System.out.println("    input = The XML File or Directory ");
            System.out.println("    output = The HTML File or Directory "); 
            System.out.println("    xslt = The XSLT specifying the transformations "); 
            System.out.println("Conditions: "); 
            System.out.println("    -  Input must exist, if Output does not exist it will be created.");
            System.out.println("    -  Transformation will only be performed on files with ");
            System.out.println("       an xml extension.");
            System.out.println("    -  If transforming a single file then Output should have an extension of html. ");   
            System.out.println("       If it does not then a html extension will be added (unless the extension is");  
            System.out.println("        specified as xml in which case it will be *replaced* by html)");
            System.out.println("    -  If Input and Output are directories then Output ");
            System.out.println("       will produce a mirror of Input's directory structure,");
            System.out.println("       with the xml extension replaced with a html");        
    }
                  

     /** The main method
       * @param args - the command line arguments
       */ 
    public static void main(String[] args) {


        
        // check that the right number of arguments have been entered
        if(args.length < 3) {
            PrintStatusMessage();            
        }
        else {
            String xmlFilename = args[0];
            String htmlFilename = args[1];
            String xsltFilename = args[2];
            
            System.out.println("Trying to convert " + xmlFilename);       
            
            XML2HTML me = new XML2HTML(xsltFilename);      
            me.ConvertXMLToHTML(xmlFilename, htmlFilename);
        }
        
        
        
    }

    
}
