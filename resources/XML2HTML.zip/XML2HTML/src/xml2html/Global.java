package xml2html;

import java.io.*;
import java.security.*;
import java.util.*;

/**
 * A utility class that contains common constant and methods that can be called from the other classes.
 * @author Alan Woodley
 */
public class Global {
    /** Suffix for XML documents */
    public static String XML_SUFFIX = ".XML"; 
    /** Suffix for text documents */
    public static String TXT_SUFFIX = ".TXT"; 
    /** Suffix for file,offset,length documents */
    public static String FOL_SUFFIX = ".FOL"; 
    /** Suffix for JPG images */
    public static String JPG_SUFFIX = ".JPG"; 
    /** Suffix for HTML documents */
    public static String HTML_SUFFIX = ".HTML";
    /** Suffix for GPXRai Log documents */
    public static String QRL_SUFFIX = ".QRL"; 
    
    
    /** Delimator for FOL documents */
    public static String FOL_DELIM = ","; 
    /** Deliminator for command line aruguments */
    public static String CMDLINE_AGRGUMENT_DELIM = "-"; 
    /** Deliminator for key,values paris in command line aruguments */
    public static String CMDLINE_KEYVALUE_DELIM = "=";
    /** Number of characters in XML suffix */
    public static int XML_SUFFIX_LENGTH = XML_SUFFIX.length(); 
    /** default xpath value */
    public static String DEFAULT_XPATH_VALUE = ""; 

    /** global error file filename */
    public static String ERROR_FILENAME = "errors.txt";  

    /**    
     * a utility method that for a given will just the name of the file when 
     * given a given a complete filepath
     * e.g. 
     *   given "c:\foo\bar.xml" return "bar"   
     * @param filename - the complete filename
     * @return - the name of the file without leading directory or suffix
     */
    public static String GetJustFileName(String filename){
        File file = new File(filename);  
        String shortFilename =  file.getName();
        if (!shortFilename.contains(".")) return shortFilename;
        // else
        int lastDotIndex = shortFilename.lastIndexOf(".");
        return shortFilename.substring(0, lastDotIndex);
          
    }


    /**
     * a utility method that produces a unique key for a given filename and xpath      
     * Used to ensure that keys are kept consistant throughout the program
     * @param filename - the element's filename
     * @param xpath - the element's xpath
     * @return - "filename:xpath"
     */  
    public static String GetKey(String filename, String xpath){
        return filename + ":" + xpath;
    }
    
    /**
     * a utility method that produces a unique key for a given filename and xpath      
     * Used to ensure that keys are kept consistant throughout the program
     * Key is returned as a number derived via MD5 hash algorithm
     * @param filename - the element's filename
     * @param xpath - the element's xpath
     * @return - MD5 representation of "filename:xpath" string
     */          
    public static Long GetHashKey(String filename, String xpath){
        try{
             // first get the unhashed key
            String key = Global.GetKey(filename,xpath);
            
            // then proceed to hash the string - source http://www.md5hashing.com/java/
            // 63bit hashcode - java Long only handles 63 bits - max value is 0x7FFFFFFFFFFFFFFF
            String h = MD5.GetMD5(key);
            h=h.substring(17);//.toUpperCase();
            return  Long.valueOf(h,16);            
        } catch( Exception e ) {
            e.printStackTrace();
            return -1L;
        }

      }
     
     /**
     * A standard binary search program that returns the index of a given object in a vector
     * @param v - A vector of objects
     * @param objp - The object whose index we are searching for
     * @param c - The comparator used to compare objects in the vector
     * @return - The index position of the object in the vector
     */
     public synchronized static int BinarySearch(Vector v, Object objp, Comparator c){
        int low = 0;
        int high = v.size() - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            int result = c.compare(objp, v.elementAt(mid));
            if (result < 0) high = mid - 1;
            else if (result > 0) low = mid + 1;
            else return mid;
        }
        return -1;
    }
     
     /**
      * Reports progress the amount of progress that has been made is signifcant 
      * @param current - The current iteration
      * @param length - The total number of iterations 
      * @param num_of_increments - Number of incremenets that are to be reported
      */
     public static void ReportProgress(int current, int length, int num_of_increments){
         
         // there are two scenarios for outputting progress
         // 1. When length is greater than the number of increments
         //       * determine a base unit (number per increment)
         //       * divide current by increment
         //       * if remainder is zero then one more increment has passed so output an update message
         //       * balue of update is equal to number of updates multipled by value for each incremement (100 / num_of_increments) 
         // 2. When length is less than the number of increments
         //       * base unit is 1
         //       * number of incremeents will be equal to length
         //       * divide current by increment
         //       * if remainder is zero then one more increment has passed so output an update message
         //       * value of update is equal to number of updates multipled by value for each incremement
         
         if (num_of_increments == 0) return;
         int  base_unit = 1;
         
         if (length > num_of_increments){
             base_unit = length / num_of_increments;
         } else{
             num_of_increments = length;
         }
         
         
//         System.out.println("num " + num_of_increments + " length " +  length + " Base unit " + base_unit);
         if((current % base_unit) == 0) 
            System.out.println((current / base_unit) * (100 / num_of_increments) + "% Done");
                   
     }

     /**
      * Reports progress the amount of progress that has been made is signifcant 
      * @param current - The current iteration
      * @param length - The total number of iterations 
      * @param num_of_increments - Number of incremenets that are to be reported
      */
     public static void ReportProgress(long current, long length, long num_of_increments){
         
         // there are two scenarios for outputting progress
         // 1. When length is greater than the number of increments
         //       * determine a base unit (number per increment)
         //       * divide current by increment
         //       * if remainder is zero then one more increment has passed so output an update message
         //       * balue of update is equal to number of updates multipled by value for each incremement (100 / num_of_increments) 
         // 2. When length is less than the number of increments
         //       * base unit is 1
         //       * number of incremeents will be equal to length
         //       * divide current by increment
         //       * if remainder is zero then one more increment has passed so output an update message
         //       * value of update is equal to number of updates multipled by value for each incremement
         
         if (num_of_increments == 0) return;
         long  base_unit = 1;
         
         if (length > num_of_increments){
             base_unit = length / num_of_increments;
         } else{
             num_of_increments = length;
         }
         
         
//         System.out.println("num " + num_of_increments + " length " +  length + " Base unit " + base_unit);
         if((current % base_unit) == 0) 
            System.out.println((current / base_unit) * (100 / num_of_increments) + "% Done");
                   
     }
     
     /**
       * Populates a hashtable with a set of command line arguments and values (in lower case)
       * arguments should be in -key=value format otherwise entire argument will be returned as the key with a empty string as its value
       * @param args - The command line arguments
       * @return - A hashtable of key,value pairs
       */
     public static Hashtable ProcessCommandsLinrArguments(String[] args){
           Hashtable ht = new Hashtable();
           
           for(int i=-0; i<args.length; i++){
               // get the next commmand line argument
               String cmd = args[i];

               // split into key value pair
               String[] cmdArr = cmd.split(CMDLINE_KEYVALUE_DELIM);
               String key = cmdArr[0].trim().toLowerCase();
               // if key begins with a minus then just ignore it
               if(key.startsWith(CMDLINE_AGRGUMENT_DELIM)) 
                    key = key.substring(1,key.length());
               String value = "";
               if(cmdArr.length > 1)
                    value = cmdArr[1].trim().toLowerCase();
               ht.put(key, value);              

           }
           
           return ht;
         
     }
     
     /**
     * Sets the filename of the global error file
     * @param filename - The filename of the global error file
     */
     public static void SetErrorFilename(String filename){
         ERROR_FILENAME = filename;
     }
     
     
}
